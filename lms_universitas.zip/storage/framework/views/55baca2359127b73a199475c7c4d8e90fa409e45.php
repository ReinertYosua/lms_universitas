
<?php $__env->startSection('title','Matakuliah'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
        <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Dashboard</a></li>
                        <li class="breadcrumb-item active"><a href="<?php echo e(route('list.courses')); ?>">Matakuliah</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->
            <?php echo $__env->make("partial.successalert", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <h4 class="card-title">Matakuliah</h4>
                                    </div>
                                    <div class="col-6 text-right">
                                        <a href="<?php echo e(route('add.courses')); ?>" class="btn mb-1 btn-primary">Tambah Matakuliah <span class="btn-icon-right"><i class="fa fa-plus"></i></span></a>
                                        
                                    </div>
                                </div>
                                <!--  -->
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>Kode Matakuliah</th>
                                                <th>Nama Matakuliah</th>
                                                <th>SKS</th>
                                                <th>Jurusan</th>
                                                <th>Deskripsi</th>
                                                <th>Active</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($mk->kode_matakuliah); ?></td>
                                                <td><?php echo e($mk->nama_matakuliah); ?></td>
                                                <td><?php echo e($mk->sks); ?></td>
                                                <td><?php echo e($mk->jurusan); ?></td>
                                                <td><?php echo e($mk->deskripsi); ?></td>
                                                <td><?php echo e($mk->active); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('detail.materi', encrypt($mk->id))); ?>" class=" btn btn-success" data-toggle="tooltip" data-placement="top" data-original-title="Tambah Materi Matakuliah"><i class="fa fa-list"></i></a>
                                                    <a href="<?php echo e(route('edit.course', encrypt($mk->id))); ?>" class=" btn btn-info" data-toggle="tooltip" data-placement="top" data-original-title="Edit Matakuliah"><i class="fa fa-edit"></i></a>
                                                    <form class="my-1"
                                                    action="<?php echo e(route('delete.course', $mk->id)); ?>" method="post" onsubmit="return confirm('Apakah anda yakin ingin menghapus Matakuliah <?php echo e($mk->nama_matakuliah); ?> ?')">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <div class="d-grid">
                                                        <button type="submit" class=" btn btn-danger" data-toggle="tooltip" data-placement="top" data-original-title="Hapus Matakuliah"><i class="fa fa-trash"></i></button>
                                                    </div>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Kode Matakuliah</th>
                                                <th>Nama Matakuliah</th>
                                                <th>SKS</th>
                                                <th>Jurusan</th>
                                                <th>Deskripsi</th>
                                                <th>Active</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div>
<!-- datatables -->
    <!-- <script src="./plugins/tables/js/jquery.dataTables.min.js"></script>
    <script src="./plugins/tables/js/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="./plugins/tables/js/datatable-init/datatable-basic.min.js"></script> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lms_universitas\resources\views/layouts/lecturer/listcourses.blade.php ENDPATH**/ ?>