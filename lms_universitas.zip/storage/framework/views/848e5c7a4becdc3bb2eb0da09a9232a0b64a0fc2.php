
<?php $__env->startSection('title','Matakuliah'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <!-- <div class="row page-titles mx-0">
        <div class="col p-md-0">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('list.courses')); ?>">Matakuliah</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)">Jadwal Kuliah</a></li>
            </ol>
        </div>
    </div> -->
    <!-- row -->

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card bg-transparent">
                    <div class="card-body ">
                        <h4 class="card-title">Matakuliah Saya</h4>
                        <div class="form-group">
                            <select name="runperiod" class="form-control form-control-sm">
                                <option value="" >Pilih Periode Berjalan</option>
                                <?php $__currentLoopData = $listperiode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option val="<?php echo e($lp->kode_periode); ?>" <?php echo e(($periode)==$lp->kode_periode?'selected': ''); ?>><?php echo e($lp->kode_periode); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-sm-6">
                <a href="<?php echo e(route('detailschedulelecturer.course',['trkodemtk'=> encrypt($tr->kode_matakuliah), 'periode'=>encrypt($tr->periode)])); ?>">
                <div class="card gradient-<?php echo e($loop->iteration); ?>">
                    <div class="card-body">
                        <h3 class="card-title text-white"><?php echo e($tr->kode_matakuliah." - ".$tr->nama_matakuliah); ?></h3>
                        <div class="d-inline-block">
                            <h2 class="text-white"><?php echo e($tr->sks); ?> SKS</h2>
                            <p class="text-white mb-0"><?php echo e($tr->periode); ?></p>
                        </div>
                        <span class="float-right display-5 opacity-5"><i class="fa fa-book"></i></span>
                    </div>
                </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
            <!-- #/ container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lms_universitas\resources\views/layouts/lecturer/schedulelecturer.blade.php ENDPATH**/ ?>