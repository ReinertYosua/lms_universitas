
<?php $__env->startSection('title','Detail Jadwal Matakuliah'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="row page-titles mx-0">
        <div class="col p-md-0">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('schedule.course')); ?>">Matakuliah</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)">Detail Jadwal Matakuliah</a></li>
            </ol>
        </div>
    </div>
    <!-- row -->

    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Detail Jadwal Matakuliah <?php echo e($matkul[0]->kode_matakuliah." - ".$matkul[0]->nama_matakuliah); ?></h4>
                        
                        <!-- <ul class="nav nav-pills mb-3">
                            <?php $__currentLoopData = $detailjadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item"><a href="#navpills-<?php echo e($loop->iteration); ?>" class="nav-link <?php echo e(($loop->iteration==1)?'active':''); ?>" data-toggle="tab" aria-expanded="false">Session <?php echo e($dt->session); ?></a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <div class="tab-content br-n pn">
                            <?php $__currentLoopData = $detailjadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div id="navpills-<?php echo e($loop->iteration); ?>" class="tab-pane <?php echo e(($loop->iteration==1)?'active':''); ?>">
                                <div class="row align-items-center">
                                    <div class="col-sm-6 col-md-4 col-xl-2">
                                        <img src="images/big/card-4.png" alt="" class="img-fluid thumbnail m-r-15">
                                    </div>
                                    <div class="col-sm-6 col-md-8 col-xl-10">
                                        <?php echo e($dt->materi); ?>

                                        <p>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache cliche tempor, williamsburg carles vegan helvetica.</p>
                                        <p>Reprehenderit butcher retro keffiyeh dreamcatcher synth. Cosby sweater eu banh mi, qui irure terry richardson ex squid.</p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div> -->


                        <!-- scroller -->
                        <div class="w-100 pt-3">
                            <div class="scroller scroller-left float-left mt-2"><i class="fa fa-chevron-left"></i></div>
                            <div class="scroller scroller-right float-right mt-2"><i class="fa fa-chevron-right"></i></div>
                            <div class="wrapper-nav">
                                <nav class="nav nav-tabs list mt-2" id="myTab" role="tablist">
                                    <?php $__currentLoopData = $detailjadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="nav-item nav-link <?php echo e(($loop->iteration==$lastsessionscore)?'active':''); ?> detailsession" data-toggle="tab" href="#tab<?php echo e($loop->iteration); ?>" role="tab" aria-controls="public" aria-expanded="true" data-id="<?php echo e(encrypt($matkul[0]->kode_matakuliah)); ?>" data-periode="<?php echo e($periode); ?>" data-sesi="<?php echo e($dt->session); ?>">Session <?php echo e($dt->session); ?></a>
                                    <input type="hidden" id="kodemk" value="<?php echo e(encrypt($matkul[0]->kode_matakuliah)); ?>">
                                    <input type="hidden" id="periode" value="<?php echo e($periode); ?>">
                                    <input type="hidden" id="session" value="<?php echo e($lastsessionscore); ?>">
                                    <!-- <a class="nav-item nav-link" href="#tab2" role="tab" data-toggle="tab">Tab 2</a> -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <!-- <a class="nav-item nav-link" href="#tab2" role="tab" data-toggle="tab">Session 14</a> -->
                                </nav>
                            </div>
                            <div class="tab-content p-3" id="myTabContent">
                                <?php $__currentLoopData = $detailjadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div role="tabpanel" class="tab-pane fade <?php echo e(($loop->iteration==$lastsessionscore)?'active':''); ?> show mt-2" id="tab<?php echo e($loop->iteration); ?>" aria-labelledby="public-tab" aria-expanded="true">
                                    <div class="row">
                                        <div class="col-lg-7">
                                            <h4><?php echo e($dt->materi); ?></h4>
                                            </br></br>
                                            <h5>Deskripsi</h5>
                                            <p><?php echo e($dt->deskripsi); ?></p>
                                            </br></br>
                                            <h5>Referensi</h5>
                                            <?php echo e($dt->referensi); ?>

                                            </br></br>
                                            <h5>Tingkat Kesulitan</h5>
                                            <span class="text-capitalize"><?php echo e($dt->tingkat_kesulitan); ?></span>
                                        </div>
                                        <div class="col-lg-5 bg-light">
                                            <div class="card card-widget" id="widgetscore">
                                                <div>

                                                </div>
                                                <!-- <div class="card-body gradient-9">
                                                    <div class="media">
                                                        <span class="card-widget__icon"><i class="fa fa-arrow-down"></i></span>
                                                        <div class="media-body">
                                                            <h2 class="card-widget__title">520</h2>
                                                            <h5 class="card-widget__subtitle">All Properties</h5>
                                                        </div>
                                                    </div>
                                                </div> -->
                                            </div>
                                            <div class="table-responsive">
                                                <table class="table">
                                                <thead>
                                                    <tr>
                                                    <th>Gaya Belajar</th>
                                                    <th>Material</th>
                                                    </tr>
                                                </thead>
                                                    <tr>
                                                        <td>General</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_materi)); ?>"><?php echo e($dt->file_materi); ?></a></td>
                                                    </tr>
                                                    <?php if($gabel=="Active"): ?>
                                                    <tr>
                                                        <td>Active</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_active)); ?>"><?php echo e($dt->file_active); ?></a></td>
                                                    </tr>
                                                    <?php endif; ?>
                                                    <?php if($gabel=="Reflective"): ?>
                                                    <tr>
                                                        <td>Reflective</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_reflective)); ?>"><?php echo e($dt->file_reflective); ?></a></td>
                                                    </tr>
                                                    <?php endif; ?>
                                                    <?php if($gabel=="Sensing"): ?>
                                                    <tr>
                                                        <td>Sensing</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_sensing)); ?>"><?php echo e($dt->file_sensing); ?></a></td>
                                                    </tr>
                                                    <?php endif; ?>
                                                    <?php if($gabel=="Intuitive"): ?>
                                                    <tr>
                                                        <td>Intuitive</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_intuitive)); ?>"><?php echo e($dt->file_intuitive); ?></a></td>
                                                    </tr>
                                                    <?php endif; ?>
                                                    <?php if($gabel=="Visual"): ?>
                                                    <tr>
                                                        <td>Visual</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_visual)); ?>"><?php echo e($dt->file_visual); ?></a></td>
                                                    </tr>
                                                    <?php endif; ?>
                                                    <?php if($gabel=="Visual"): ?>
                                                    <tr>
                                                        <td>Verbal</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_verbal)); ?>"><?php echo e($dt->file_verbal); ?></a></td>
                                                    </tr>
                                                    <?php endif; ?>
                                                    <?php if($gabel=="Sequential"): ?>
                                                    <tr>
                                                        <td>Sequential</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_sequential)); ?>"><?php echo e($dt->file_sequential); ?></a></td>
                                                    </tr>
                                                    <?php endif; ?>
                                                    <?php if($gabel=="Global"): ?>
                                                    <tr>
                                                        <td>Global</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_global)); ?>"><?php echo e($dt->file_global); ?></a></td>
                                                    </tr>
                                                    <?php endif; ?>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <!-- scroller -->

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
// var jq = jQuery.noConflict(true);
//$(".viewdetails").hide()
$(document).ready(function(){
    var kodemk = $("#kodemk").val();
    var periode = $("#periode").val();
    var session = $("#session").val();
    //alert(kodemk+"-"+periode+"-"+session);
    if(kodemk!=""){

        // AJAX request
        var url = "<?php echo e(route('detailstudent.score',[':kodemk',':periode',':session'])); ?>";
        url = url.replace(':kodemk', kodemk).replace(':periode', periode).replace(':session', session);
        
        // Empty modal data
        $('#widgetscore div').empty();

        $.ajax({
            url: url,
            dataType: 'json',
            success: function(response){

                // Add employee details
                $('#widgetscore div').html(response.html);

               
            }
        });
    }

});
$('#myTab').on('click','.detailsession',function(){
        var kodemk = $(this).attr('data-id');
        var periode = $(this).attr('data-periode');
        var session = $(this).attr('data-sesi');
        //alert(kodemk+"-"+periode+"-"+session);
        if(kodemk!=""){

            // AJAX request
            var url = "<?php echo e(route('detailstudent.score',[':kodemk',':periode',':session'])); ?>";
            url = url.replace(':kodemk', kodemk).replace(':periode', periode).replace(':session', session);
            
            // Empty modal data
            $('#widgetscore div').empty();

            $.ajax({
                url: url,
                dataType: 'json',
                success: function(response){
                    // Add employee details
                    $('#widgetscore div').html(response.html);

                }
            });
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lms_universitas\resources\views/layouts/student/detailcourse.blade.php ENDPATH**/ ?>