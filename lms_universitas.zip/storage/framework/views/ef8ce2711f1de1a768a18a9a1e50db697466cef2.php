
<?php $__env->startSection('title','Materi Matakuliah'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="row page-titles mx-0">
        <div class="col p-md-0">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('list.courses')); ?>">Matakuliah</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('detail.materi', encrypt($mk[0]->id))); ?>">Materi Matakuliah</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)">Edit Materi Matakuliah</a></li>
            </ol>
        </div>
    </div>
    <!-- row -->

    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Edit Materi Matakuliah <?php echo e($mk[0]->kode_matakuliah." - ".$mk[0]->nama_matakuliah); ?></h4>
                        <div class="form-validation">
                        
                            <form class="form-valide" action="<?php echo e(route('updatedetail.course')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="session">Season <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                        <input type="hidden" name="id_mtk" value="<?php echo e(encrypt($mk[0]->id)); ?>">
                                        <input type="hidden" name="id_mmk" value="<?php echo e(encrypt($mmk[0]->id)); ?>">
                                        <input type="number" value="<?php echo e(old('session') ?? $mmk[0]->session); ?>" class="form-control <?php $__errorArgs = ['season'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="session" name="session" placeholder="Masukkan session">
                                        <?php $__errorArgs = ['session'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="materi">Materi <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                        <input type="text" value="<?php echo e(old('materi') ?? $mmk[0]->materi); ?>" class="form-control <?php $__errorArgs = ['materi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="sks" name="materi" placeholder="Masukkan nama materi..">
                                    <?php $__errorArgs = ['materi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="jenis_materi">Jenis Materi <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                        <select class="form-control" id="jenis_materi" name="jenis_materi">
                                            <option value="">Silahkan Pilih</option>
                                            <option value="Multimedia" <?php echo e((old('jenis_materi') ?? $mmk[0]->jenis_materi)=='Multimedia'?'selected': ''); ?>>Multimedia</option>
                                            <option value="PPT" <?php echo e((old('jenis_materi') ?? $mmk[0]->jenis_materi)=='PPT'?'selected': ''); ?>>Presentasi</option>
                                            <option value="PDF" <?php echo e((old('jenis_materi') ?? $mmk[0]->jenis_materi)=='PDF'?'selected': ''); ?>>PDF</option>
                                            <option value="Book" <?php echo e((old('jenis_materi') ?? $mmk[0]->jenis_materi)=='Book'?'selected': ''); ?>>Buku</option>
                                            <option value="Diktat" <?php echo e((old('jenis_materi') ?? $mmk[0]->jenis_materi)=='Diktat'?'selected': ''); ?>>Diktat</option>
                                            <option value="Doc" <?php echo e((old('jenis_materi') ?? $mmk[0]->jenis_materi)=='Doc'?'selected': ''); ?>>Dokumen Word</option>
                                            <option value="Xls" <?php echo e((old('jenis_materi') ?? $mmk[0]->jenis_materi)=='Xls'?'selected': ''); ?>>Dokumen Excel</option>
                                            <option value="Text" <?php echo e((old('jenis_materi') ?? $mmk[0]->jenis_materi)=='Text'?'selected': ''); ?>>Dokumen Teks</option>
                                            <option value="Tugas" <?php echo e((old('jenis_materi') ?? $mmk[0]->jenis_materi)=='Tugas'?'selected': ''); ?>>Tugas</option>
                                            <option value="Project" <?php echo e((old('jenis_materi') ?? $mmk[0]->jenis_materi)=='Project'?'selected': ''); ?>>Project</option>
                                            <option value="Diskusi" <?php echo e((old('jenis_materi') ?? $mmk[0]->jenis_materi)=='Diskusi'?'selected': ''); ?>>Diskusi</option>
                                            <option value="Referensi" <?php echo e((old('jenis_materi') ?? $mmk[0]->jenis_materi)=='Referensi'?'selected': ''); ?>>Referensi</option>
                                        </select>
                                    <?php $__errorArgs = ['jenis_materi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="deskripsi">Deskripsi <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                        <textarea class="form-control <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="deskripsi" name="deskripsi" rows="5" placeholder="Masukkan deskripsi matakuliah"><?php echo e(old('deskripsi') ?? $mmk[0]->deskripsi); ?></textarea>
                                    <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="referensi">Referensi <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                        <textarea class="form-control <?php $__errorArgs = ['referensi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="referensi" name="referensi" rows="5" placeholder="Masukkan referensi"><?php echo e(old('referensi') ?? $mmk[0]->referensi); ?></textarea>
                                    <?php $__errorArgs = ['referensi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="kesulitan">Tingkat Kesulitan <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                        <select class="form-control" id="kesulitan" name="kesulitan">
                                            <option value="">Silahkan Pilih</option>
                                            <option value="hign"<?php echo e((old('kesulitan') ?? $mmk[0]->tingkat_kesulitan)=='high'?'selected': ''); ?>>Sulit</option>
                                            <option value="medium" <?php echo e((old('kesulitan') ?? $mmk[0]->tingkat_kesulitan)=='medium'?'selected': ''); ?>>Sedang</option>
                                            <option value="low" <?php echo e((old('kesulitan') ?? $mmk[0]->tingkat_kesulitan)=='low'?'selected': ''); ?>>Mudah</option>
                                            
                                        </select>
                                    <?php $__errorArgs = ['kesulitan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="filemateri">File Materi <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                    <input type="file" accept=".ppt,.pptx,.pdf" class="form-control <?php $__errorArgs = ['filemateri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="filemateri" placeholder="Upload File Materi" >
                                    <?php $__errorArgs = ['filemateri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="filemateriactive">File Materi Active <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                    <input type="file" accept=".ppt,.pptx,.pdf" class="form-control <?php $__errorArgs = ['filemateriactive'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="filemateriactive" placeholder="Upload File Materi Active" >
                                    <?php $__errorArgs = ['filemateriactive'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="filematerireflective">File Materi Reflective <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                    <input type="file" accept=".ppt,.pptx,.pdf" class="form-control <?php $__errorArgs = ['filematerireflective'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="filematerireflective" placeholder="Upload File Materi Reflective" >
                                    <?php $__errorArgs = ['filematerireflective'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="filematerisensing">File Materi Sensing <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                    <input type="file" accept=".ppt,.pptx,.pdf" class="form-control <?php $__errorArgs = ['filematerisensing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="filematerisensing" placeholder="Upload File Materi Sensing" >
                                    <?php $__errorArgs = ['filematerisensing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="filemateriintuitive">File Materi Intuitive <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                    <input type="file" accept=".ppt,.pptx,.pdf" class="form-control <?php $__errorArgs = ['filemateriintuitive'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="filemateriintuitive" placeholder="Upload File Materi Intuitive" >
                                    <?php $__errorArgs = ['filemateriintuitive'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="filematerivisual">File Materi Visual <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                    <input type="file" accept=".ppt,.pptx,.pdf" class="form-control <?php $__errorArgs = ['filematerivisual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="filematerivisual" placeholder="Upload File Materi Visual" >
                                    <?php $__errorArgs = ['filematerivisual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="filemateriverbal">File Materi Verbal <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                    <input type="file" accept=".ppt,.pptx,.pdf" class="form-control <?php $__errorArgs = ['filemateriverbal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="filemateriverbal" placeholder="Upload File Materi Verbal" >
                                    <?php $__errorArgs = ['filemateriverbal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="filematerisequential">File Materi Sequential <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                    <input type="file" accept=".ppt,.pptx,.pdf" class="form-control <?php $__errorArgs = ['filematerisequential'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="filematerisequential" placeholder="Upload File Materi Sequential" >
                                    <?php $__errorArgs = ['filematerisequential'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="filemateriglobal">File Materi Global <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                    <input type="file" accept=".ppt,.pptx,.pdf" class="form-control <?php $__errorArgs = ['filemateriglobal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="filemateriglobal" placeholder="Upload File Materi Global" >
                                    <?php $__errorArgs = ['filemateriglobal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                
                                <div class="form-group row">
                                    <div class="col-lg-8 ml-auto">
                                        <input type="submit" class="btn btn-primary" value="Submit">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
            <!-- #/ container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lms_universitas\resources\views/layouts/lecturer/editdetailmateri.blade.php ENDPATH**/ ?>