
<?php $__env->startSection('title','Detail Jadwal Matakuliah'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="row page-titles mx-0">
        <div class="col p-md-0">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('schedulelec.course')); ?>">Matakuliah</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)">Detail Jadwal Matakuliah</a></li>
            </ol>
        </div>
    </div>
    <!-- row -->

    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Detail Matakuliah <?php echo e($matkul[0]->kode_matakuliah." - ".$matkul[0]->nama_matakuliah); ?></h4>


                        <!-- scroller -->
                        <div class="w-100 pt-3">
                            <div class="scroller scroller-left float-left mt-2"><i class="fa fa-chevron-left"></i></div>
                            <div class="scroller scroller-right float-right mt-2"><i class="fa fa-chevron-right"></i></div>
                            <div class="wrapper-nav">
                                <nav class="nav nav-tabs list mt-2" id="myTab" role="tablist">
                                    <?php $__currentLoopData = $detailjadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="nav-item nav-link <?php echo e(($loop->iteration==1)?'active':''); ?> detailsession" data-toggle="tab" href="#tab<?php echo e($loop->iteration); ?>" role="tab" aria-controls="public" aria-expanded="true" data-id="<?php echo e(encrypt($matkul[0]->kode_matakuliah)); ?>" data-periode="<?php echo e($periode); ?>" data-sesi="<?php echo e($dt->session); ?>">Session <?php echo e($dt->session); ?></a>
                                    <input type="hidden" id="kodemk" value="<?php echo e(encrypt($matkul[0]->kode_matakuliah)); ?>">
                                    <input type="hidden" id="periode" value="<?php echo e($periode); ?>">
                                    <input type="hidden" id="session" value="<?php echo e($dt->session); ?>">
                                    <!-- <a class="nav-item nav-link" href="#tab2" role="tab" data-toggle="tab">Tab 2</a> -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <!-- <a class="nav-item nav-link" href="#tab2" role="tab" data-toggle="tab">Session 14</a> -->
                                </nav>
                            </div>
                            <div class="tab-content p-3" id="myTabContent">
                                <?php $__currentLoopData = $detailjadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div role="tabpanel" class="tab-pane fade <?php echo e(($loop->iteration==1)?'active':''); ?> show mt-2" id="tab<?php echo e($loop->iteration); ?>" aria-labelledby="public-tab" aria-expanded="true">
                                    <div class="row">
                                        <div class="col-lg-7">
                                            <h4><?php echo e($dt->materi); ?></h4>
                                            </br></br>
                                            <h5>Deskripsi</h5>
                                            <p><?php echo e($dt->deskripsi); ?></p>
                                            </br></br>
                                            <h5>Referensi</h5>
                                            <?php echo e($dt->referensi); ?>

                                            </br></br>
                                            <h5>Tingkat Kesulitan</h5>
                                            <?php echo e($dt->tingkat_kesulitan); ?>

                                        </div>
                                        <div class="col-lg-5 bg-light">
                                            <div class="table-responsive">
                                                <table class="table">
                                                <thead>
                                                    <tr>
                                                    <th>Gaya Belajar</th>
                                                    <th>Material</th>
                                                    </tr>
                                                </thead>
                                                    <tr>
                                                        <td>General</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_materi)); ?>"><?php echo e($dt->file_materi); ?></a></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Active</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_active)); ?>"><?php echo e($dt->file_active); ?></a></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Reflective</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_reflective)); ?>"><?php echo e($dt->file_reflective); ?></a></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Sensing</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_sensing)); ?>"><?php echo e($dt->file_sensing); ?></a></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Intuitive</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_intuitive)); ?>"><?php echo e($dt->file_intuitive); ?></a></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Visual</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_visual)); ?>"><?php echo e($dt->file_visual); ?></a></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Verbal</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_verbal)); ?>"><?php echo e($dt->file_verbal); ?></a></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Sequential</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_sequential)); ?>"><?php echo e($dt->file_sequential); ?></a></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Global</td><td><a href="<?php echo e(route('downloadmateri.course', $dt->file_global)); ?>"><?php echo e($dt->file_global); ?></a></td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    </br>
                                    </br>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="table-responsive">
                                                <table class="table table-striped table-bordered" id="tblempinfo">
                                                    <thead>
                                                        <tr>
                                                            <th>No</th>
                                                            <th>NIM</th>
                                                            <th>Nama Mahasiswa</th>
                                                            <th>Nilai Sesi <?php echo e($dt->session); ?></th>
                                                            <th>Topic Mastery</th>
                                                            <th>Affection</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody></tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <!-- scroller -->

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    // var jq = jQuery.noConflict(true);
    //$(".viewdetails").hide()
   $(document).ready(function(){
        var kodemk = $("#kodemk").val();
        var periode = $("#periode").val();
        var session = $("#session").val();
        //alert(kodemk+"-"+periode+"-"+session);
        if(kodemk!=""){

            // AJAX request
            var url = "<?php echo e(route('detaillecturer.score',[':kodemk',':periode',':session'])); ?>";
            url = url.replace(':kodemk', kodemk).replace(':periode', periode).replace(':session', session);
            
            // Empty modal data
            $('#tblempinfo tbody').empty();

            $.ajax({
                url: url,
                dataType: 'json',
                success: function(response){

                    // Add employee details
                    $('#tblempinfo tbody').html(response.html);

                }
            });
        }

   });
   $('#myTab').on('click','.detailsession',function(){
          var kodemk = $(this).attr('data-id');
          var periode = $(this).attr('data-periode');
          var session = $(this).attr('data-sesi');
          //alert(kodemk+"-"+periode+"-"+session);
          if(kodemk!=""){

             // AJAX request
             var url = "<?php echo e(route('detaillecturer.score',[':kodemk',':periode',':session'])); ?>";
             url = url.replace(':kodemk', kodemk).replace(':periode', periode).replace(':session', session);
             
             // Empty modal data
             $('#tblempinfo tbody').empty();

             $.ajax({
                 url: url,
                 dataType: 'json',
                 success: function(response){

                     // Add employee details
                     $('#tblempinfo tbody').html(response.html);

                    
                 }
             });
          }
      });
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lms_universitas\resources\views/layouts/lecturer/detailcourselecturer.blade.php ENDPATH**/ ?>