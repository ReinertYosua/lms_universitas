
<?php $__env->startSection('title','Matakuliah'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
        <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Dashboard</a></li>
                        <li class="breadcrumb-item active"><a href="<?php echo e(route('list.courses')); ?>">Matakuliah</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Materi Matakuliah</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->
            <?php echo $__env->make("partial.successalert", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <h4 class="card-title">Detail Materi <?php echo e($mk[0]->kode_matakuliah." - ".$mk[0]->nama_matakuliah); ?></h4>
                                    </div>
                                    <div class="col-6 text-right">
                                        <a href="<?php echo e(route('addmateri.course', encrypt($mk[0]->id))); ?>" class="btn mb-1 btn-primary">Tambah Detail Materi <span class="btn-icon-right"><i class="fa fa-plus"></i></span></a>
                                        
                                    </div>
                                </div>
                                <!--  -->
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>Sesion</th>
                                                <th>Materi</th>
                                                <th>Jenis Materi</th>
                                                <th>Deskripsi</th>
                                                <th>Referensi</th>
                                                <th>Tingkat Kesulitan</th>
                                                <th>File Materi</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $materimk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mmk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($mmk->session); ?></td>
                                                <td><?php echo e($mmk->materi); ?></td>
                                                <td><?php echo e($mmk->jenis_materi); ?></td>
                                                <td><?php echo e($mmk->deskripsi); ?></td>
                                                <td><?php echo e($mmk->referensi); ?></td>
                                                <td><?php echo e($mmk->tingkat_kesulitan); ?></td>
                                                <td>
                                                    <table>
                                                        <tr>
                                                            <td>General</td><td><a href="<?php echo e(route('downloadmateri.course', $mmk->file_materi)); ?>"><?php echo e($mmk->file_materi); ?></a></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Active</td><td><a href="<?php echo e(route('downloadmateri.course', $mmk->file_active)); ?>"><?php echo e($mmk->file_active); ?></a></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Reflective</td><td><a href="<?php echo e(route('downloadmateri.course', $mmk->file_reflective)); ?>"><?php echo e($mmk->file_reflective); ?></a></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Sensing</td><td><a href="<?php echo e(route('downloadmateri.course', $mmk->file_sensing)); ?>"><?php echo e($mmk->file_sensing); ?></a></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Intuitive</td><td><a href="<?php echo e(route('downloadmateri.course', $mmk->file_intuitive)); ?>"><?php echo e($mmk->file_intuitive); ?></a></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Visual</td><td><a href="<?php echo e(route('downloadmateri.course', $mmk->file_visual)); ?>"><?php echo e($mmk->file_visual); ?></a></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Verbal</td><td><a href="<?php echo e(route('downloadmateri.course', $mmk->file_verbal)); ?>"><?php echo e($mmk->file_verbal); ?></a></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Sequential</td><td><a href="<?php echo e(route('downloadmateri.course', $mmk->file_sequential)); ?>"><?php echo e($mmk->file_sequential); ?></a></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Global</td><td><a href="<?php echo e(route('downloadmateri.course', $mmk->file_global)); ?>"><?php echo e($mmk->file_global); ?></a></td>
                                                        </tr>
                                                    </table>
                                                    
                                                </td>
                                                <td>
                                                    
                                                    <a href="<?php echo e(route('editmateri.course', ['idmkdet'=>encrypt($mmk->id), 'idmk'=>encrypt($mk[0]->id)])); ?>" class=" btn btn-info" data-toggle="tooltip" data-placement="top" data-original-title="Edit Matakuliah"><i class="fa fa-edit"></i></a>
                                                    <form class="my-1"
                                                    action="<?php echo e(route('deletemateri.course', ['idmmk'=>encrypt($mmk->id), 'idmk'=>encrypt($mk[0]->id)])); ?>" method="post" onsubmit="return confirm('Apakah anda yakin ingin menghapus Materi <?php echo e($mmk->materi); ?> ?')">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <div class="d-grid">
                                                        <button type="submit" class=" btn btn-danger" data-toggle="tooltip" data-placement="top" data-original-title="Hapus Matakuliah"><i class="fa fa-trash"></i></button>
                                                    </div>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Sesion</th>
                                                <th>Materi</th>
                                                <th>Jenis Materi</th>
                                                <th>Deskripsi</th>
                                                <th>Referensi</th>
                                                <th>Tingkat Kesulitan</th>
                                                <th>Link Materi</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div>
<!-- datatables -->
    <!-- <script src="./plugins/tables/js/jquery.dataTables.min.js"></script>
    <script src="./plugins/tables/js/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="./plugins/tables/js/datatable-init/datatable-basic.min.js"></script> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lms_universitas\resources\views/layouts/lecturer/listdetailmateri.blade.php ENDPATH**/ ?>