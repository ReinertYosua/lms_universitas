
<?php $__env->startSection('titleauth','Login'); ?>
<?php $__env->startSection('contenauth'); ?>
    <div class="login-form-bg h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100">
                <div class="col-xl-6">
                    <div class="form-input-content">
                        <div class="card login-form mb-0">
                            <?php echo $__env->make("partial.successalert", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('partial.dangeralert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="card-body pt-5">
                            <img class="rounded mx-auto d-block" src="<?php echo e(asset('images')); ?>/logo-utama.png" alt="">
        
                                <form method="post" action="<?php echo e(url('login/proses')); ?>" class="mt-5 mb-5 login-input">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <input autofocus type="email" class="form-control 
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            is-invalid
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        " placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                
                                    <div class="form-group">
                                        <input type="password" class="form-control
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            is-invalid
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        " placeholder="Password" name="password">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                   
                                    <button class="btn login-form__btn submit w-100">Sign In</button>
                                </form>
                                <div class="container">
                                    <div class="row">
                                        <div class="col-6 text-center">
                                        <a href="/registrationdosen" class="btn mb-1 btn-outline-info">Sign Up as Lecturer</a>
                                        </div>
                                        <div class="col-6 text-center">
                                            <a href="/registrationmahasiswa" class="btn mb-1 btn-outline-info">Sign Up as Student</a>
                                        
                                        </div>
                                    </div>
                                </div>
                                <!-- <p class="mt-5 login-form__footer">Dont have account? <a href="/register" class="text-primary">Sign Up as Lecturer</a></p> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
    

  
<?php echo $__env->make('auth.headerauth.masterauth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lms_universitas\resources\views/auth/login.blade.php ENDPATH**/ ?>