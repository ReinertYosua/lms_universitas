
<?php $__env->startSection('titleauth','Kuesioner Gaya Belajar'); ?>
<?php $__env->startSection('contenauth'); ?>

<div class="login-form-bg h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100">
                <div class="col-xl-8">
                    <div class="form-input-content">
                        <div class="card login-form mb-0">
                            <div class="card-body pt-5">
                                    
                                    <a class="text-center" href="/"> <h4>Quiz Gaya Belajar</h4></a>
                                <?php echo $__env->make('partial.dangeralert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <form class="mt-5 mb-5 login-input" action="<?php echo e(route('kuesioner.store')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <table class="table" border="1px solid black" width="100%">
                                        <?php $__currentLoopData = $quiz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($q->id); ?></td>
                                            <td>
                                                <?php echo e($q->soal); ?> 
                                            </td>
                                            <td>
                                                <div class="form-check">
                                                    <input style="cursor: pointer;" class="form-check-input" type="radio" value="1" name="<?php echo e($q->kode_kuis); ?>" id="<?php echo e($q->pil1); ?>" required>
                                                    <label style="cursor: pointer;" class="form-check-label" for="<?php echo e($q->pil1); ?>">
                                                        <?php echo e($q->pil1); ?>

                                                    </label>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="form-check">
                                                    <input style="cursor: pointer;" class="form-check-input" type="radio" value="0" name="<?php echo e($q->kode_kuis); ?>" id="<?php echo e($q->pil2); ?>" required>
                                                    <label style="cursor: pointer;" class="form-check-label" for="<?php echo e($q->pil2); ?>">
                                                        <?php echo e($q->pil2); ?>

                                                    </label>
                                                </div>
                                            </td>
                                        
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                    <input type="submit" value="Submit" class="btn login-form__btn submit w-100">
                                    <!-- <button class="btn login-form__btn submit w-100">Sign in</button> -->
                                </form>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.headerauth.masterauth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lms_universitas\resources\views/layouts/student/kuesioner.blade.php ENDPATH**/ ?>